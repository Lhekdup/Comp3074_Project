package ca.messagingapp.gbc.messagingbackend.dto;

public record OfferDto(
    String toUserId,
    String sdp
) {}