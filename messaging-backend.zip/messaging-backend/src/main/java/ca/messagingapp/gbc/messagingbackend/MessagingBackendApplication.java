package ca.messagingapp.gbc.messagingbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagingBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MessagingBackendApplication.class, args);
    }

}
